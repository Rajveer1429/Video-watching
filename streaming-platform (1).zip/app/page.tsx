"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Upload, Play, Star, Clock, Calendar, Search, Plus, Film, Tv } from "lucide-react"
import Image from "next/image"

interface Movie {
  id: number
  title: string
  type: "movie" | "series"
  genre: string
  year: number
  rating: number
  duration: string
  description: string
  thumbnail: string
  videoUrl?: string
}

export default function StreamingPlatform() {
  const [movies, setMovies] = useState<Movie[]>([
    {
      id: 1,
      title: "Cosmic Adventure",
      type: "movie",
      genre: "Sci-Fi",
      year: 2024,
      rating: 8.5,
      duration: "2h 15m",
      description: "An epic journey through space and time.",
      thumbnail: "/placeholder.svg?height=400&width=300",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    },
    {
      id: 2,
      title: "Mystery Harbor",
      type: "series",
      genre: "Thriller",
      year: 2023,
      rating: 9.1,
      duration: "8 episodes",
      description: "Dark secrets unfold in a coastal town.",
      thumbnail: "/placeholder.svg?height=400&width=300",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    },
    {
      id: 3,
      title: "Digital Dreams",
      type: "movie",
      genre: "Drama",
      year: 2024,
      rating: 7.8,
      duration: "1h 45m",
      description: "A story about technology and human connection.",
      thumbnail: "/placeholder.svg?height=400&width=300",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    },
    {
      id: 4,
      title: "Forest Legends",
      type: "series",
      genre: "Fantasy",
      year: 2023,
      rating: 8.9,
      duration: "12 episodes",
      description: "Magical creatures and ancient mysteries.",
      thumbnail: "/placeholder.svg?height=400&width=300",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
    },
  ])

  const [searchTerm, setSearchTerm] = useState("")
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null)
  const [isUploadOpen, setIsUploadOpen] = useState(false)
  const [uploadForm, setUploadForm] = useState({
    title: "",
    type: "movie" as "movie" | "series",
    genre: "",
    year: new Date().getFullYear(),
    description: "",
    file: null as File | null,
  })

  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)

  const filteredMovies = movies.filter(
    (movie) =>
      movie.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      movie.genre.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleUpload = async () => {
    if (uploadForm.title && uploadForm.genre && uploadForm.description) {
      setIsUploading(true)
      setUploadProgress(0)

      // Simulate upload progress
      const progressInterval = setInterval(() => {
        setUploadProgress((prev) => {
          if (prev >= 90) {
            clearInterval(progressInterval)
            return 90
          }
          return prev + 10
        })
      }, 200)

      // Simulate upload delay
      await new Promise((resolve) => setTimeout(resolve, 2000))

      let videoUrl = ""
      if (uploadForm.file) {
        // Create a URL for the uploaded file
        videoUrl = URL.createObjectURL(uploadForm.file)
      }

      const newMovie: Movie = {
        id: movies.length + 1,
        title: uploadForm.title,
        type: uploadForm.type,
        genre: uploadForm.genre,
        year: uploadForm.year,
        rating: 0,
        duration: uploadForm.type === "movie" ? "2h 0m" : "10 episodes",
        description: uploadForm.description,
        thumbnail: `/placeholder.svg?height=400&width=300&query=${uploadForm.title}+${uploadForm.genre}+poster`,
        videoUrl: videoUrl || "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      }

      setUploadProgress(100)
      setMovies([...movies, newMovie])

      // Reset form
      setUploadForm({
        title: "",
        type: "movie",
        genre: "",
        year: new Date().getFullYear(),
        description: "",
        file: null,
      })

      setTimeout(() => {
        setIsUploading(false)
        setUploadProgress(0)
        setIsUploadOpen(false)
      }, 500)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-md border-b border-white/10 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Film className="h-8 w-8 text-purple-400" />
              <h1 className="text-2xl font-bold text-white">StreamFlix</h1>
            </div>

            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search movies & series..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64 bg-white/10 border-white/20 text-white placeholder:text-gray-400"
                />
              </div>

              <Dialog open={isUploadOpen} onOpenChange={setIsUploadOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-purple-600 hover:bg-purple-700">
                    <Plus className="h-4 w-4 mr-2" />
                    Upload Content
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-slate-800 border-slate-700 text-white">
                  <DialogHeader>
                    <DialogTitle>Upload New Content</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="title">Title</Label>
                      <Input
                        id="title"
                        value={uploadForm.title}
                        onChange={(e) => setUploadForm({ ...uploadForm, title: e.target.value })}
                        className="bg-slate-700 border-slate-600"
                      />
                    </div>

                    <div>
                      <Label htmlFor="type">Type</Label>
                      <Select
                        value={uploadForm.type}
                        onValueChange={(value: "movie" | "series") => setUploadForm({ ...uploadForm, type: value })}
                      >
                        <SelectTrigger className="bg-slate-700 border-slate-600">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-slate-700 border-slate-600">
                          <SelectItem value="movie">Movie</SelectItem>
                          <SelectItem value="series">Series</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="genre">Genre</Label>
                      <Input
                        id="genre"
                        value={uploadForm.genre}
                        onChange={(e) => setUploadForm({ ...uploadForm, genre: e.target.value })}
                        className="bg-slate-700 border-slate-600"
                      />
                    </div>

                    <div>
                      <Label htmlFor="year">Year</Label>
                      <Input
                        id="year"
                        type="number"
                        value={uploadForm.year}
                        onChange={(e) => setUploadForm({ ...uploadForm, year: Number.parseInt(e.target.value) })}
                        className="bg-slate-700 border-slate-600"
                      />
                    </div>

                    <div>
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        value={uploadForm.description}
                        onChange={(e) => setUploadForm({ ...uploadForm, description: e.target.value })}
                        className="bg-slate-700 border-slate-600"
                      />
                    </div>

                    <div>
                      <Label htmlFor="file">Video File *</Label>
                      <div className="border-2 border-dashed border-slate-600 rounded-lg p-6 text-center hover:border-purple-400 transition-colors">
                        <Upload className="h-12 w-12 mx-auto text-gray-400 mb-2" />
                        <p className="text-gray-400 mb-2">
                          {uploadForm.file
                            ? uploadForm.file.name
                            : "Drag & drop your video file here or click to browse"}
                        </p>
                        <p className="text-xs text-gray-500 mb-2">
                          Supported formats: MP4, AVI, MOV, WebM (Max: 500MB)
                        </p>
                        <Input
                          id="file"
                          type="file"
                          accept="video/mp4,video/avi,video/mov,video/webm"
                          onChange={(e) => setUploadForm({ ...uploadForm, file: e.target.files?.[0] || null })}
                          className="mt-2 bg-slate-700 border-slate-600 file:bg-purple-600 file:text-white file:border-0 file:rounded file:px-4 file:py-2"
                        />
                        {uploadForm.file && (
                          <div className="mt-2 text-sm text-green-400">
                            ✓ File selected: {(uploadForm.file.size / (1024 * 1024)).toFixed(2)} MB
                          </div>
                        )}
                      </div>
                    </div>

                    {isUploading && (
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Uploading...</span>
                          <span>{uploadProgress}%</span>
                        </div>
                        <div className="w-full bg-slate-700 rounded-full h-2">
                          <div
                            className="bg-purple-600 h-2 rounded-full transition-all duration-300"
                            style={{ width: `${uploadProgress}%` }}
                          ></div>
                        </div>
                      </div>
                    )}

                    <Button
                      onClick={handleUpload}
                      disabled={!uploadForm.title || !uploadForm.genre || !uploadForm.description || isUploading}
                      className="w-full bg-purple-600 hover:bg-purple-700 disabled:opacity-50"
                    >
                      {isUploading ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          Uploading...
                        </>
                      ) : (
                        <>
                          <Upload className="h-4 w-4 mr-2" />
                          Upload Content
                        </>
                      )}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 px-4">
        <div className="container mx-auto text-center">
          <h2 className="text-5xl font-bold text-white mb-6">
            Stream Your Favorite
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
              {" "}
              Movies & Series
            </span>
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Discover, upload, and share amazing content with our community. Watch anywhere, anytime.
          </p>
        </div>
      </section>

      {/* Content Grid */}
      <section className="py-12 px-4">
        <div className="container mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-3xl font-bold text-white">Featured Content</h3>
            <div className="flex space-x-2">
              <Badge variant="secondary" className="bg-purple-600/20 text-purple-300">
                {filteredMovies.filter((m) => m.type === "movie").length} Movies
              </Badge>
              <Badge variant="secondary" className="bg-blue-600/20 text-blue-300">
                {filteredMovies.filter((m) => m.type === "series").length} Series
              </Badge>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredMovies.map((movie) => (
              <Card
                key={movie.id}
                className="bg-slate-800/50 border-slate-700 hover:bg-slate-800/70 transition-all duration-300 group cursor-pointer"
              >
                <CardHeader className="p-0">
                  <div className="relative overflow-hidden rounded-t-lg">
                    <Image
                      src={movie.thumbnail || "/placeholder.svg"}
                      alt={movie.title}
                      width={300}
                      height={400}
                      className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                      <Button
                        size="lg"
                        className="bg-purple-600 hover:bg-purple-700"
                        onClick={() => setSelectedMovie(movie)}
                      >
                        <Play className="h-5 w-5 mr-2" />
                        Watch Now
                      </Button>
                    </div>
                    <Badge className="absolute top-2 left-2 bg-purple-600">
                      {movie.type === "movie" ? <Film className="h-3 w-3 mr-1" /> : <Tv className="h-3 w-3 mr-1" />}
                      {movie.type}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-4">
                  <CardTitle className="text-white mb-2">{movie.title}</CardTitle>
                  <p className="text-gray-400 text-sm mb-3 line-clamp-2">{movie.description}</p>
                  <div className="flex items-center justify-between text-sm text-gray-400">
                    <span className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      {movie.year}
                    </span>
                    <span className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      {movie.duration}
                    </span>
                  </div>
                </CardContent>
                <CardFooter className="p-4 pt-0">
                  <div className="flex items-center justify-between w-full">
                    <Badge variant="outline" className="border-purple-400 text-purple-300">
                      {movie.genre}
                    </Badge>
                    <div className="flex items-center text-yellow-400">
                      <Star className="h-4 w-4 mr-1 fill-current" />
                      <span className="text-sm font-medium">{movie.rating}</span>
                    </div>
                  </div>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {movies.some((movie) => movie.rating === 0) && (
        <section className="py-12 px-4">
          <div className="container mx-auto">
            <h3 className="text-3xl font-bold text-white mb-8">Recently Uploaded</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {movies
                .filter((movie) => movie.rating === 0)
                .map((movie) => (
                  <Card
                    key={movie.id}
                    className="bg-gradient-to-br from-purple-800/30 to-pink-800/30 border-purple-500/50 hover:from-purple-800/50 hover:to-pink-800/50 transition-all duration-300 group cursor-pointer"
                  >
                    <CardHeader className="p-0">
                      <div className="relative overflow-hidden rounded-t-lg">
                        <Image
                          src={movie.thumbnail || "/placeholder.svg"}
                          alt={movie.title}
                          width={300}
                          height={400}
                          className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                          <Button
                            size="lg"
                            className="bg-purple-600 hover:bg-purple-700"
                            onClick={() => setSelectedMovie(movie)}
                          >
                            <Play className="h-5 w-5 mr-2" />
                            Watch Now
                          </Button>
                        </div>
                        <Badge className="absolute top-2 left-2 bg-green-600">NEW</Badge>
                        <Badge className="absolute top-2 right-2 bg-purple-600">
                          {movie.type === "movie" ? <Film className="h-3 w-3 mr-1" /> : <Tv className="h-3 w-3 mr-1" />}
                          {movie.type}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-4">
                      <CardTitle className="text-white mb-2">{movie.title}</CardTitle>
                      <p className="text-gray-400 text-sm mb-3 line-clamp-2">{movie.description}</p>
                      <div className="flex items-center justify-between text-sm text-gray-400">
                        <span className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1" />
                          {movie.year}
                        </span>
                        <span className="flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          {movie.duration}
                        </span>
                      </div>
                    </CardContent>
                    <CardFooter className="p-4 pt-0">
                      <div className="flex items-center justify-between w-full">
                        <Badge variant="outline" className="border-purple-400 text-purple-300">
                          {movie.genre}
                        </Badge>
                        <div className="text-green-400 text-sm font-medium">Just Uploaded!</div>
                      </div>
                    </CardFooter>
                  </Card>
                ))}
            </div>
          </div>
        </section>
      )}

      {/* Video Player Modal */}
      {selectedMovie && (
        <Dialog open={!!selectedMovie} onOpenChange={() => setSelectedMovie(null)}>
          <DialogContent className="max-w-4xl bg-black border-slate-700">
            <DialogHeader>
              <DialogTitle className="text-white">{selectedMovie.title}</DialogTitle>
            </DialogHeader>
            <div className="aspect-video bg-slate-900 rounded-lg overflow-hidden">
              <video controls className="w-full h-full" poster={selectedMovie.thumbnail} crossOrigin="anonymous">
                <source src={selectedMovie.videoUrl || "/placeholder-video.mp4"} type="video/mp4" />
                <p className="text-white p-4">Your browser does not support the video tag.</p>
              </video>
            </div>
            <div className="text-white space-y-2">
              <div className="flex items-center space-x-4 text-sm text-gray-400">
                <span className="flex items-center">
                  <Calendar className="h-4 w-4 mr-1" />
                  {selectedMovie.year}
                </span>
                <span className="flex items-center">
                  <Clock className="h-4 w-4 mr-1" />
                  {selectedMovie.duration}
                </span>
                <span className="flex items-center">
                  <Star className="h-4 w-4 mr-1 fill-current text-yellow-400" />
                  {selectedMovie.rating}
                </span>
                <Badge variant="outline" className="border-purple-400 text-purple-300">
                  {selectedMovie.genre}
                </Badge>
              </div>
              <p className="text-gray-300">{selectedMovie.description}</p>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}
