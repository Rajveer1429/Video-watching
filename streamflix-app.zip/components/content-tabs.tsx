"use client"

import { useState } from "react"

interface ContentItem {
  title: string
  description: string
  isNew?: boolean
}

interface ContentData {
  series: ContentItem[]
  movies: ContentItem[]
  blogs: ContentItem[]
  news: ContentItem[]
}

interface ContentTabsProps {
  contentData: ContentData
}

export default function ContentTabs({ contentData }: ContentTabsProps) {
  const [activeTab, setActiveTab] = useState("series")

  const tabs = [
    { id: "series", label: "Series" },
    { id: "movies", label: "Movies" },
    { id: "blogs", label: "Blogs" },
    { id: "news", label: "News" },
  ]

  const getTabTitle = (tabId: string) => {
    switch (tabId) {
      case "series":
        return "Latest Series"
      case "movies":
        return "Popular Movies"
      case "blogs":
        return "Latest Blogs"
      case "news":
        return "Entertainment News"
      default:
        return "Content"
    }
  }

  // Check if any tab has new content
  const hasNewContent = (tabId: string) => {
    return contentData[tabId as keyof ContentData].some((item) => item.isNew)
  }

  return (
    <section id="content" className="py-20 px-[5%] max-w-7xl mx-auto">
      <div className="flex justify-center mb-10 gap-5 flex-wrap">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-8 py-3 rounded-full border-2 border-red-600 transition-all duration-300 font-medium relative ${
              activeTab === tab.id
                ? "bg-red-600 text-white shadow-[0_8px_20px_rgba(229,9,20,0.3)] -translate-y-0.5"
                : "bg-transparent text-white hover:bg-red-600 hover:-translate-y-0.5 hover:shadow-[0_8px_20px_rgba(229,9,20,0.3)]"
            }`}
          >
            {tab.label}
            {hasNewContent(tab.id) && (
              <span className="absolute -top-1 -right-1 bg-green-500 text-white text-xs px-2 py-1 rounded-full animate-pulse">
                NEW
              </span>
            )}
          </button>
        ))}
      </div>

      <div className="animate-fade-in">
        <h2 className="text-3xl md:text-4xl font-bold mb-10 text-center bg-gradient-to-r from-red-600 to-red-400 bg-clip-text text-transparent">
          {getTabTitle(activeTab)}
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {contentData[activeTab as keyof ContentData].map((item, index) => (
            <div
              key={index}
              className={`bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl p-6 transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_20px_40px_rgba(229,9,20,0.2)] relative overflow-hidden group ${
                item.isNew
                  ? "border-2 border-green-500 shadow-[0_0_20px_rgba(34,197,94,0.3)]"
                  : "border border-red-600/10"
              }`}
            >
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-600 to-red-400 transform -translate-x-full group-hover:translate-x-0 transition-transform duration-300"></div>
              <h3 className="text-red-600 text-xl font-semibold mb-4 flex items-center gap-2">
                {item.title}
                {item.isNew && (
                  <span className="text-green-500 text-sm font-normal bg-green-500/20 px-2 py-1 rounded-full animate-pulse">
                    [NEW]
                  </span>
                )}
              </h3>
              <p className="text-gray-300 leading-relaxed">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
