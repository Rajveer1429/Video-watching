"use client"

interface FooterProps {
  onManagerAccess: () => void
}

export default function Footer({ onManagerAccess }: FooterProps) {
  return (
    <footer className="bg-gradient-to-br from-black to-gray-900 pt-16 pb-5 border-t-2 border-red-600/20 mt-20">
      <div className="px-[5%] max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-10">
          <div>
            <h4 className="text-red-600 text-xl font-semibold mb-5">StreamFlix</h4>
            <p className="text-gray-300">Your ultimate entertainment destination</p>
          </div>

          <div>
            <h4 className="text-red-600 text-xl font-semibold mb-5">Quick Links</h4>
            <div className="space-y-2">
              {["Home", "Series", "Movies", "Blogs"].map((link) => (
                <a
                  key={link}
                  href={`#${link.toLowerCase()}`}
                  className="block text-gray-300 hover:text-red-600 transition-colors duration-300"
                >
                  {link}
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-red-600 text-xl font-semibold mb-5">Contact</h4>
            <p className="text-gray-300 mb-2">Email: info@streamflix.com</p>
            <p className="text-gray-300">Phone: +91 9876543210</p>
          </div>

          <div>
            <h4 className="text-red-600 text-xl font-semibold mb-5">Follow Us</h4>
            <div className="flex gap-4">
              {["Facebook", "Twitter", "Instagram"].map((social) => (
                <a
                  key={social}
                  href="#"
                  className="bg-red-600/10 px-4 py-2 rounded-full border border-red-600/30 text-gray-300 hover:bg-red-600 hover:-translate-y-0.5 transition-all duration-300"
                >
                  {social}
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Manager Access Section */}
        <div className="text-center my-10 p-10 bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl border-2 border-red-600/30 max-w-2xl mx-auto shadow-[0_10px_30px_rgba(229,9,20,0.1)]">
          <h4 className="text-red-600 text-2xl font-bold mb-4 drop-shadow-[0_0_10px_rgba(229,9,20,0.3)]">
            Content Management
          </h4>
          <p className="text-gray-400 mb-6 text-lg">For content managers and authorized personnel</p>
          <button
            onClick={onManagerAccess}
            className="bg-gradient-to-r from-red-600 to-red-700 text-white px-10 py-4 rounded-full text-xl font-bold cursor-pointer transition-all duration-300 uppercase tracking-wide shadow-[0_8px_25px_rgba(229,9,20,0.3)] hover:-translate-y-1 hover:shadow-[0_15px_35px_rgba(229,9,20,0.4)] relative overflow-hidden group"
          >
            <span className="absolute top-0 left-[-100%] w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent transition-all duration-500 group-hover:left-[100%]"></span>
            Upload Content
          </button>
        </div>

        <div className="text-center pt-8 border-t border-red-600/20 text-gray-400">
          <p>&copy; 2025 StreamFlix. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
