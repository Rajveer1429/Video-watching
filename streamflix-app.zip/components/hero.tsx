"use client"

export default function Hero() {
  const scrollToContent = () => {
    document.getElementById("content")?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section
      id="home"
      className="h-screen bg-gradient-to-br from-black via-gray-900 to-black flex items-center justify-center text-center relative"
      style={{
        backgroundImage: `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.7)), url('/placeholder.svg?height=1080&width=1920')`,
      }}
    >
      <div className="max-w-4xl animate-fade-in-up">
        <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-red-600 to-red-400 bg-clip-text text-transparent">
          Unlimited Entertainment
        </h1>
        <p className="text-xl md:text-2xl mb-8 opacity-90">
          Watch unlimited movies, series, and stay updated with latest news and blogs
        </p>
        <button
          onClick={scrollToContent}
          className="bg-gradient-to-r from-red-600 to-red-700 text-white px-10 py-4 rounded-full text-xl font-semibold hover:-translate-y-1 transition-all duration-300 shadow-[0_8px_25px_rgba(229,9,20,0.3)] hover:shadow-[0_12px_35px_rgba(229,9,20,0.5)]"
        >
          Start Watching
        </button>
      </div>
    </section>
  )
}
