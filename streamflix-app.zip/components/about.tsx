export default function About() {
  const stats = [
    { number: "10,000+", label: "Movies & Series" },
    { number: "50+", label: "Countries" },
    { number: "24/7", label: "Streaming" },
    { number: "HD", label: "Quality" },
  ]

  const features = [
    {
      icon: "🎬",
      title: "Latest Content",
      description: "Stay updated with the newest releases and trending content from around the world.",
    },
    {
      icon: "📱",
      title: "Multi-Device",
      description: "Watch anywhere, anytime on your favorite device - phone, tablet, or computer.",
    },
    {
      icon: "🌟",
      title: "Premium Quality",
      description: "Enjoy crystal clear HD streaming with superior audio quality.",
    },
    {
      icon: "🔄",
      title: "Regular Updates",
      description: "Fresh content added regularly to keep your entertainment experience exciting.",
    },
  ]

  return (
    <section id="about" className="py-20 px-[5%] max-w-7xl mx-auto">
      <h2 className="text-3xl md:text-4xl font-bold mb-10 text-center bg-gradient-to-r from-red-600 to-red-400 bg-clip-text text-transparent">
        About StreamFlix
      </h2>

      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-xl md:text-2xl leading-relaxed opacity-90 max-w-4xl mx-auto mb-10">
            StreamFlix is your ultimate destination for premium entertainment content. We bring you the latest movies,
            trending series, insightful blogs, and breaking entertainment news all in one place.
          </p>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div
                key={index}
                className="bg-gradient-to-br from-gray-800 to-gray-900 p-6 rounded-2xl border border-red-600/20 hover:-translate-y-1 transition-all duration-300 hover:shadow-[0_15px_30px_rgba(229,9,20,0.2)]"
              >
                <h3 className="text-3xl md:text-4xl font-bold text-red-600 mb-2">{stat.number}</h3>
                <p className="text-gray-300 text-lg">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl p-8 text-center transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_20px_40px_rgba(229,9,20,0.2)] border border-red-600/10 relative overflow-hidden group"
            >
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-600 to-red-400 transform -translate-x-full group-hover:translate-x-0 transition-transform duration-300"></div>
              <div className="text-5xl mb-5 block">{feature.icon}</div>
              <h4 className="text-red-600 text-xl font-semibold mb-4">{feature.title}</h4>
              <p className="text-gray-300 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
