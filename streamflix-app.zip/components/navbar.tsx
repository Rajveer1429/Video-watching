"use client"

import { useState, useEffect } from "react"

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 100)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" })
    }
  }

  return (
    <nav
      className={`fixed top-0 w-full z-50 transition-all duration-300 px-[5%] py-4 ${
        scrolled ? "bg-black/95" : "bg-black/90"
      } backdrop-blur-md`}
    >
      <div className="flex justify-between items-center">
        <div className="text-3xl font-bold text-red-600 drop-shadow-[0_0_20px_rgba(229,9,20,0.5)]">StreamFlix</div>
        <div className="hidden md:flex gap-8">
          {[
            { name: "Home", id: "home" },
            { name: "Series", id: "content" },
            { name: "Movies", id: "content" },
            { name: "Blogs", id: "content" },
            { name: "News", id: "content" },
            { name: "About", id: "about" },
          ].map((link) => (
            <button
              key={link.name}
              onClick={() => scrollToSection(link.id)}
              className="text-white hover:text-red-600 transition-all duration-300 relative group hover:-translate-y-0.5"
            >
              {link.name}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-red-600 transition-all duration-300 group-hover:w-full"></span>
            </button>
          ))}
        </div>
      </div>
    </nav>
  )
}
