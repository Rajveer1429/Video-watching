"use client"

import type React from "react"

import { useState } from "react"
import { X } from "lucide-react"

interface ManagerLoginProps {
  isOpen: boolean
  onClose: () => void
  onLogin: (success: boolean) => void
}

export default function ManagerLogin({ isOpen, onClose, onLogin }: ManagerLoginProps) {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  const MANAGER_EMAIL = "rajveershrivastav34@gmail.com"
  const MANAGER_PASSWORD = "Rajveer1"

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (email === MANAGER_EMAIL && password === MANAGER_PASSWORD) {
      onLogin(true)
      alert("Manager login successful! Upload panel is now accessible.")
      setEmail("")
      setPassword("")
    } else {
      onLogin(false)
      alert("Invalid credentials! Access denied.")
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-[2000] p-4">
      <div className="bg-gradient-to-br from-gray-800 to-gray-900 p-10 rounded-2xl border-2 border-red-600 max-w-md w-full relative">
        <button onClick={onClose} className="absolute top-4 right-4 text-white hover:text-red-600 transition-colors">
          <X size={24} />
        </button>

        <h3 className="text-center text-2xl font-bold text-red-600 mb-8">Manager Login</h3>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="email" className="block text-red-600 font-semibold mb-2">
              Email:
            </label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full bg-white/10 border border-red-600/30 rounded-lg p-3 text-white focus:outline-none focus:border-red-600 focus:shadow-[0_0_10px_rgba(229,9,20,0.3)]"
            />
          </div>

          <div>
            <label htmlFor="password" className="block text-red-600 font-semibold mb-2">
              Password:
            </label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full bg-white/10 border border-red-600/30 rounded-lg p-3 text-white focus:outline-none focus:border-red-600 focus:shadow-[0_0_10px_rgba(229,9,20,0.3)]"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-gradient-to-r from-red-600 to-red-700 text-white py-3 rounded-lg font-semibold hover:-translate-y-0.5 transition-all duration-300 shadow-[0_8px_20px_rgba(229,9,20,0.4)]"
          >
            Login
          </button>
        </form>
      </div>
    </div>
  )
}
