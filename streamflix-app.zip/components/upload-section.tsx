"use client"

import type React from "react"

import { useState } from "react"

interface UploadSectionProps {
  isManagerLoggedIn: boolean
  onContentUpload: (type: string, title: string, description: string) => void
}

export default function UploadSection({ isManagerLoggedIn, onContentUpload }: UploadSectionProps) {
  const [contentType, setContentType] = useState("")
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [mediaFile, setMediaFile] = useState<File | null>(null)
  const [thumbnail, setThumbnail] = useState<File | null>(null)
  const [uploadMessage, setUploadMessage] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!isManagerLoggedIn) {
      alert("Unauthorized access!")
      return
    }

    // Simulate upload process
    const sectionName =
      contentType === "movies"
        ? "Movies"
        : contentType === "series"
          ? "Series"
          : contentType === "blogs"
            ? "Blogs"
            : "News"

    setUploadMessage(
      `✅ Upload successful! Content "${title}" has been added to ${sectionName} section. Switch to the ${sectionName} tab to view it.`,
    )

    // Add content to the appropriate section
    onContentUpload(contentType, title, description)

    // Reset form
    setContentType("")
    setTitle("")
    setDescription("")
    setMediaFile(null)
    setThumbnail(null)

    // Clear message after 8 seconds (longer to give user time to read)
    setTimeout(() => {
      setUploadMessage("")
    }, 8000)
  }

  return (
    <div
      id="uploadSection"
      className="bg-gradient-to-br from-black to-gray-800 rounded-2xl p-10 mx-[5%] my-10 border-2 border-red-600 max-w-4xl mx-auto"
    >
      <h2 className="text-3xl font-bold text-red-600 mb-8 text-center">Content Upload Manager</h2>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="contentType" className="block text-red-600 font-semibold mb-2">
              Content Type:
            </label>
            <select
              id="contentType"
              value={contentType}
              onChange={(e) => setContentType(e.target.value)}
              required
              className="w-full bg-white/10 border border-red-600/30 rounded-lg p-3 text-white focus:outline-none focus:border-red-600 focus:shadow-[0_0_10px_rgba(229,9,20,0.3)]"
            >
              <option value="">Select Content Type</option>
              <option value="series">Series</option>
              <option value="movies">Movie</option>
              <option value="blogs">Blog</option>
              <option value="news">News</option>
            </select>
          </div>

          <div>
            <label htmlFor="title" className="block text-red-600 font-semibold mb-2">
              Title:
            </label>
            <input
              type="text"
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              placeholder="Enter content title"
              className="w-full bg-white/10 border border-red-600/30 rounded-lg p-3 text-white focus:outline-none focus:border-red-600 focus:shadow-[0_0_10px_rgba(229,9,20,0.3)]"
            />
          </div>
        </div>

        <div>
          <label htmlFor="description" className="block text-red-600 font-semibold mb-2">
            Description:
          </label>
          <textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
            rows={4}
            placeholder="Enter content description"
            className="w-full bg-white/10 border border-red-600/30 rounded-lg p-3 text-white focus:outline-none focus:border-red-600 focus:shadow-[0_0_10px_rgba(229,9,20,0.3)] resize-none"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="mediaFile" className="block text-red-600 font-semibold mb-2">
              Media File:
            </label>
            <input
              type="file"
              id="mediaFile"
              onChange={(e) => setMediaFile(e.target.files?.[0] || null)}
              accept="video/*,image/*"
              required
              className="w-full bg-white/10 border border-red-600/30 rounded-lg p-3 text-white focus:outline-none focus:border-red-600 focus:shadow-[0_0_10px_rgba(229,9,20,0.3)]"
            />
          </div>

          <div>
            <label htmlFor="thumbnail" className="block text-red-600 font-semibold mb-2">
              Thumbnail:
            </label>
            <input
              type="file"
              id="thumbnail"
              onChange={(e) => setThumbnail(e.target.files?.[0] || null)}
              accept="image/*"
              className="w-full bg-white/10 border border-red-600/30 rounded-lg p-3 text-white focus:outline-none focus:border-red-600 focus:shadow-[0_0_10px_rgba(229,9,20,0.3)]"
            />
          </div>
        </div>

        <button
          type="submit"
          className="w-full bg-gradient-to-r from-red-600 to-red-700 text-white py-4 rounded-lg text-xl font-semibold hover:-translate-y-0.5 transition-all duration-300 shadow-[0_8px_20px_rgba(229,9,20,0.4)]"
        >
          Upload Content
        </button>
      </form>

      {uploadMessage && (
        <div className="mt-6 p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
          <p className="text-green-500 text-center mb-3">{uploadMessage}</p>
          <div className="text-center">
            <button
              onClick={() => {
                const sectionName =
                  contentType === "movies"
                    ? "Movies"
                    : contentType === "series"
                      ? "Series"
                      : contentType === "blogs"
                        ? "Blogs"
                        : "News"
                // Scroll to content section and switch tab
                document.getElementById("content")?.scrollIntoView({ behavior: "smooth" })
                // We'll need to pass a callback to switch tabs
              }}
              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors duration-300"
            >
              View Uploaded Content
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
