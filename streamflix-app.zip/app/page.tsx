"use client"

import { useState, useEffect } from "react"
import Navbar from "@/components/navbar"
import Hero from "@/components/hero"
import ContentTabs from "@/components/content-tabs"
import About from "@/components/about"
import Footer from "@/components/footer"
import ManagerLogin from "@/components/manager-login"
import UploadSection from "@/components/upload-section"

export default function Home() {
  const [isManagerLoggedIn, setIsManagerLoggedIn] = useState(false)
  const [showLoginModal, setShowLoginModal] = useState(false)
  const [showUploadSection, setShowUploadSection] = useState(false)
  const [contentData, setContentData] = useState({
    series: [
      {
        title: "The Crown",
        description:
          "A biographical drama about the reign of Queen Elizabeth II, exploring the personal and political challenges of the British royal family.",
      },
      {
        title: "Stranger Things",
        description:
          "A science fiction horror series set in the 1980s, following a group of kids as they encounter supernatural forces in their small town.",
      },
      {
        title: "Money Heist",
        description:
          "A Spanish heist thriller series about a group of robbers who carry out an elaborate plan to steal from the Royal Mint of Spain.",
      },
      {
        title: "The Witcher",
        description:
          "A fantasy drama series based on the book series, following Geralt of Rivia, a monster hunter in a world full of magic and political intrigue.",
      },
      {
        title: "Sacred Games",
        description:
          "An Indian crime thriller series that follows a troubled police officer and a criminal mastermind in a race against time to save Mumbai.",
      },
      {
        title: "Bridgerton",
        description:
          "A period romance series set in Regency-era London, following the romantic entanglements of the Bridgerton family.",
      },
    ],
    movies: [
      {
        title: "Avengers: Endgame",
        description:
          "The epic conclusion to the Infinity Saga, where the remaining Avengers assemble to reverse Thanos' actions and restore balance to the universe.",
      },
      {
        title: "The Dark Knight",
        description:
          "Batman faces his greatest challenge as the Joker wreaks havoc on Gotham City, testing his moral code and resolve.",
      },
      {
        title: "Inception",
        description:
          "A thief who enters people's dreams to steal secrets must perform the impossible task of inception - planting an idea in someone's mind.",
      },
      {
        title: "Parasite",
        description:
          "A dark comedy thriller about a poor family who infiltrates the lives of a wealthy family, leading to unexpected consequences.",
      },
      {
        title: "Dangal",
        description:
          "The inspiring story of wrestler Mahavir Singh Phogat who trains his daughters to become world-class wrestlers.",
      },
      {
        title: "3 Idiots",
        description:
          "A comedy-drama about three friends whose lives take different paths after graduation, exploring education and following your passion.",
      },
    ],
    blogs: [
      {
        title: "The Future of Streaming",
        description:
          "How streaming platforms are revolutionizing entertainment consumption and what to expect in the coming years.",
      },
      {
        title: "Behind the Scenes: Movie Magic",
        description:
          "Exploring the incredible work that goes into creating the visual effects and cinematography of modern blockbusters.",
      },
      {
        title: "International Cinema Rising",
        description:
          "How global content is breaking barriers and finding audiences worldwide, creating a truly connected entertainment ecosystem.",
      },
      {
        title: "The Art of Storytelling",
        description:
          "What makes a great story? Analyzing the elements that keep audiences engaged and emotionally invested.",
      },
      {
        title: "Technology in Entertainment",
        description:
          "From AI to virtual reality, how cutting-edge technology is shaping the future of entertainment experiences.",
      },
      {
        title: "Cultural Impact of Series",
        description: "How TV series are influencing culture, fashion, and social conversations around the world.",
      },
    ],
    news: [
      {
        title: "New Marvel Phase Announced",
        description:
          "Marvel Studios reveals their ambitious plans for the next phase of the MCU, including new heroes and storylines.",
      },
      {
        title: "Bollywood Box Office Records",
        description: "Latest Indian films breaking box office records and setting new benchmarks for the industry.",
      },
      {
        title: "Streaming Wars Heat Up",
        description:
          "Major platforms announce new content strategies and exclusive deals to compete for viewer attention.",
      },
      {
        title: "Award Season Predictions",
        description: "Early predictions and analysis of the upcoming award season's most promising contenders.",
      },
      {
        title: "International Film Festivals",
        description: "Coverage of major film festivals around the world and the emerging talent being showcased.",
      },
      {
        title: "Celebrity Interviews",
        description:
          "Exclusive interviews with your favorite stars discussing their latest projects and upcoming ventures.",
      },
    ],
  })

  useEffect(() => {
    // Check for upload access in URL
    const urlParams = new URLSearchParams(window.location.search)
    if (urlParams.get("upload") === "true" || window.location.hash === "#upload") {
      setShowLoginModal(true)
    }

    // Console command for upload access
    console.log('Manager Upload Access: Type "upload" to access upload panel')
    ;(window as any).upload = () => setShowLoginModal(true)

    // Keyboard shortcut for upload access (Ctrl + U)
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.key === "u") {
        e.preventDefault()
        setShowLoginModal(true)
      }
    }

    document.addEventListener("keydown", handleKeyDown)
    return () => document.removeEventListener("keydown", handleKeyDown)
  }, [])

  const handleManagerLogin = (success: boolean) => {
    if (success) {
      setIsManagerLoggedIn(true)
      setShowLoginModal(false)
      setShowUploadSection(true)
      // Scroll to upload section after a brief delay
      setTimeout(() => {
        document.getElementById("uploadSection")?.scrollIntoView({ behavior: "smooth" })
      }, 100)
    }
  }

  const handleContentUpload = (type: string, title: string, description: string) => {
    const newContent = { title, description, isNew: true }
    setContentData((prev) => ({
      ...prev,
      [type]: [newContent, ...prev[type as keyof typeof prev]],
    }))

    // Remove "NEW" tag after 10 seconds
    setTimeout(() => {
      setContentData((prev) => ({
        ...prev,
        [type]: prev[type as keyof typeof prev].map((item, index) => (index === 0 ? { ...item, isNew: false } : item)),
      }))
    }, 10000)

    // Show alert with specific section name
    const sectionName =
      type === "movies" ? "Movies" : type === "series" ? "Series" : type === "blogs" ? "Blogs" : "News"

    setTimeout(() => {
      alert(
        `Content successfully added to ${sectionName} section! Check the ${sectionName} tab to see your new content.`,
      )
    }, 500)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black to-gray-900 text-white overflow-x-hidden">
      <Navbar />
      <Hero />
      <ContentTabs contentData={contentData} />
      <About />
      <Footer onManagerAccess={() => setShowLoginModal(true)} />

      {showUploadSection && (
        <UploadSection isManagerLoggedIn={isManagerLoggedIn} onContentUpload={handleContentUpload} />
      )}

      <ManagerLogin isOpen={showLoginModal} onClose={() => setShowLoginModal(false)} onLogin={handleManagerLogin} />
    </div>
  )
}
